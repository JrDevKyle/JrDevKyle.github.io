#include <iostream>
#include <fstream>
#include "CSVparser.hpp"
#include <vector>
using namespace std;

struct Course
{
    vector<string> preRequisites;
	string courseNum;
    string courseName;
    Course()
	{
		
	}
};

struct Node
{
    Node *right;
    Node *left;
	Course course;
    Node()
    {
		right = nullptr;
        left = nullptr;  
    }

    Node(Course selectedCourse) : Node()
    {
        this->course = selectedCourse;
    }
};

class CourseT
{
private:
	void printInfoCourse(Node *node, string courseNum);
    void printSampleSchedule(Node *node);
	void addANode(Node *node, Course course);
    Node *rootPT;
	
public:
    void RemoveRecursive(Node *node);
    void InsertValue(Course course);
    int PrereqCoursesNum(Course course);
    void PrintSampleSchedule();
    void PrintInfoCourse(string courseNum);
	CourseT();
    virtual ~CourseT();
};

CourseT::CourseT()
{
    rootPT = nullptr;
}

CourseT::~CourseT()
{
    RemoveRecursive(rootPT);
}

void CourseT::InsertValue(Course course)
{
    if (rootPT == nullptr)
        rootPT = new Node(course);
    else
        this->addANode(rootPT, course);
}

void CourseT::addANode(Node *node, Course course)
{
    if (node->course.courseNum.compare(course.courseNum) > 0)
    {
        if (node->left == nullptr)
            node->left = new Node(course);
        else
            this->addANode(node->left, course);
    }

    else
    {
        if (node->right == nullptr)
            node->right = new Node(course);
        else
            this->addANode(node->right, course);
    }
}

void CourseT::RemoveRecursive(Node *node)
{
    if (node)
    {
        RemoveRecursive(node->left);
        RemoveRecursive(node->right);
        delete node;
    }
}

int CourseT::PrereqCoursesNum(Course course)
{
    int count = 0;
    for (unsigned int i = 0; i < course.preRequisites.size(); i++)
    {
        if (course.preRequisites.at(i).length() > 0)
            count++;
    }
    return count;
}

void CourseT::printInfoCourse(Node *selectedNode, string courseNum)
{
    while (selectedNode != nullptr)
    {
        if (selectedNode->course.courseNum.compare(courseNum) == 0)
        {
            cout << endl
                 << selectedNode->course.courseNum << ", " << selectedNode->course.courseName << endl;
            unsigned int sizeOfPrereq = PrereqCoursesNum(selectedNode->course);
            cout << "Prerequisite(s): ";
            unsigned int i = 0;
            for (i = 0; i < sizeOfPrereq; i++)
            {
                cout << selectedNode->course.preRequisites.at(i);
                if (i != sizeOfPrereq - 1)
                    cout << ", ";
            } // If no preRequisites, inform user and return to stop the search
            if (i == 0)
                cout << "No preRequisites required.";
            cout << endl;
            return;
        }

        else if (courseNum.compare(selectedNode->course.courseNum) < 0)
            selectedNode = selectedNode->left;

        else
            selectedNode = selectedNode->right;
    }
    cout << "Sorry, the course " << courseNum << " could not be located." << endl;
}

bool coursesLoading(string pathOfFile, CourseT *coursePT)
{
    try
    {
        ifstream fileCoursePath(pathOfFile);
        if (fileCoursePath.is_open())
        {
            while (!fileCoursePath.eof())
            {
                vector<string> infoCourse;
                string dataOfCourse;
                getline(fileCoursePath, dataOfCourse);
                while (dataOfCourse.length() > 0)
                {
                    unsigned int comma = dataOfCourse.find(',');
                    if (comma < 100)
                    {
                        infoCourse.push_back(dataOfCourse.substr(0, comma));
                        dataOfCourse.erase(0, comma + 1);
                    }

                    else
                    {
                        infoCourse.push_back(dataOfCourse.substr(0, dataOfCourse.length()));
                        dataOfCourse = "";
                    }
                }

                Course course;
                course.courseNum = infoCourse[0];
                course.courseName = infoCourse[1];

                for (unsigned int i = 2; i < infoCourse.size(); i++)
                {
                    course.preRequisites.push_back(infoCourse[i]);
                }

                coursePT->InsertValue(course);
            }
            fileCoursePath.close();
            return true;
        }
    }

    catch (exception& e)
    {
        
    }
    return false;
}

void CourseT::PrintSampleSchedule()
{
    this->printSampleSchedule(rootPT);
}

void CourseT::PrintInfoCourse(string theNumCourse)
{
    this->printInfoCourse(rootPT, theNumCourse);
}

void CourseT::printSampleSchedule(Node *theNode)
{
    if (theNode != nullptr)
    {
        printSampleSchedule(theNode->left);
        cout << theNode->course.courseNum << ", " << theNode->course.courseName << endl;
        printSampleSchedule(theNode->right);
    }
    return;
}

int main(int switUse, char *vectorPT[])
{
	string courseId;
    string csvPath;
	
	
    switch (switUse)
    {
    case 2:
        csvPath = vectorPT[1];
        break;
    case 3:
        csvPath = vectorPT[1];
        courseId = vectorPT[2];
        break;
    default:
        csvPath = "";
        break;
    }

    CourseT *coursePT = nullptr;
    cout << "\nWelcome to the course planner.\n"
         << endl;

    string firstChoice = "0";
    int choiceOfUser = firstChoice[0] - '0';

    while (choiceOfUser != 4)
    {
        cout << " 1. Load Data Structure" << endl;
        cout << " 2. Print Course List" << endl;
        cout << " 3. Print Course" << endl;
        cout << " 4. Exit" << endl;
        cout << "\nWhat would you like to do? ";
        cin >> firstChoice;

        if (firstChoice.length() == 1)
            choiceOfUser = firstChoice[0] - '0';
        else
            choiceOfUser = 0;
		
        bool valid = 1;

        switch (choiceOfUser)
        {
        case 1:
            if (coursePT == nullptr)
                coursePT = new CourseT();

            if (csvPath.length() == 0)
            {
                cout << "Please type the name of the file that has data: ";
                cin >> csvPath;
            }

            valid = coursesLoading(csvPath, coursePT);
            if (valid)
                cout << "Loaded courses.\n"
                     << endl;
					 
            else
                cout << "Sorry, the file has not been found.\n"
                     << endl;
            csvPath = "";
            break;

        case 2:
            if (coursePT != nullptr && valid)
            {
                cout << "Here is a sample schedule:\n"
                     << endl;
                coursePT->PrintSampleSchedule();
                cout << endl;
            }
			
            else
                cout << "Please select option 1 first if you want to load courses.\n"
                     << endl;
            break;

        case 3:
            if (coursePT != nullptr && valid)
            {
                if (courseId.length() == 0)
                {
                    cout << "What course do you want to know about? ";
                    cin >> courseId;
                    for (auto &choiceOfUser : courseId)
                        choiceOfUser = toupper(choiceOfUser);
                }
                coursePT->PrintInfoCourse(courseId);
                cout << endl;
            }
            else
                cout << "Please select option 1 first if you want to load courses.\n"
                     << endl;
            courseId = "";
            break;

        default:
            if (choiceOfUser != 4)
            {
                cout << firstChoice << " is not a valid option\n"
                     << endl;
                break;
            }
        }
    }

    cout << "\nThank you for using the course planner!" << endl;
    return 0;
}
