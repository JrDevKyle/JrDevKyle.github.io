package com.gamingroom.gameauth;

import io.dropwizard.Configuration;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.hibernate.validator.constraints.*;
import javax.validation.constraints.*;

public class GameAuthConfiguration extends Configuration {

}