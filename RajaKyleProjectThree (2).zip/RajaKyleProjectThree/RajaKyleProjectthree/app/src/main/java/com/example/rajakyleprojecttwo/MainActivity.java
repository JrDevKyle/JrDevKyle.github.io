package com.example.rajakyleprojecttwo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;


public class MainActivity extends AppCompatActivity
{
    private Button SayHello;
    private EditText nameText;
    private TextView textGreeting;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        nameText = (EditText) findViewById(R.id.nameText);

        textGreeting = (TextView) findViewById(R.id.textGreeting);

        SayHello = (Button) findViewById(R.id.buttonSayHello);

        SayHello.setEnabled(false);


        nameText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) { }

            @Override
            public void afterTextChanged(Editable s) {

                if (s.toString().equals(""))
                {
                    SayHello.setEnabled(false);
                }

                else
                {
                    SayHello.setEnabled(true);
                }
            }
        });
    }

    public void SayHello(View view)
    {
        String userName = nameText.getText().toString();

        if (userName.equals(""))
        {
            textGreeting.setText("Please type a name"); // update text greeting
        }

        else
        {
            textGreeting.setText("Hello, "+userName+"!"); // update text greeting
        }
    }
}
