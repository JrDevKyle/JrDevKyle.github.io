from pymongo import MongoClient
from bson.objectid import ObjectId

class AnimalShelter(object):
    """ CRUD operations for Animal collection in MongoDB """
    
    
    def _init_(self, user, password):
        #Initializing the MongoClient. This helps to access the MongoDB databases and collections.
        self.client = MongoClient('mongodb://%s:%s@localhost:46648' % ('aacuserr', 'Abcdefgh89'))
        self.database = self.client['AAC']
        
# Create this method to implement the C in CRUD.
    def create(self, data):
        if data is not None:
            self.database.animals.insert(data) # data should be dictionary
            
        else:
            raise Exception("Nothing to save, because data parameter is empty")
        
# Create this method to implement the R in CRUD.
    def read(self, readData):
        if readData:
            data = self.database.animals.find(readData, {"_id": False})

        else:
            data = self.database.animals.find({}, {"_id": False})
            return data
        
# Create this method to implement the U in CRUD
    def update(self, updateData):
        try:
            result = self.database.animals.update(pairToFind, PairToReplace)
            return dumps(self.read(pairToFind))
        except Exception as e:
            return e
    
#Create this method to implement the D in CRUD
    def delete(self, deleteData):
        try:
            result = self.database.animals.delete(deleteData, key_value_pairs)
            return dumps(self.read(key_value_pairs))
        except Exception as e:
            return e

        

